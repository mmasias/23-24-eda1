import java.util.List;
import java.util.Scanner;
public class Arbol {

    nodo raiz=new nodo("Encuesta",null);
    nodo dia1=new nodo("dia1",raiz);
    nodo dia2=new nodo("dia2",raiz);
    nodo dia3=new nodo("dia3",raiz);
    nodo dia4=new nodo("dia4",raiz);
    nodo dia5=new nodo("dia5",raiz);
    nodo desa=new nodo("desayuno",dia1);
    nodo media=new nodo("almuerzo",dia1);
    nodo almu=new nodo("almuerzo",dia1);
    nodo merienda=new nodo("merienda",dia1);
    nodo cena=new nodo("cena",dia1);

    Encuesta encuesta = new Encuesta();
    Arbol arbol = new Arbol("Encuesta");

    String dato;
    Desayuno desayuno = new Desayuno();
    nodo nodo = new nodo(dato, null);

    int dias;



    public Arbol(String dato) {
        this.dato = dato;
        this.raiz = new nodo(dato, null);
    }
    public Arbol() {
        this.dato = dato;
    }

    public void añaderama(String dato, nodo padre){
        nodo hijo = new nodo(dato, padre);

    }
    public void ramanodo(List<String> lista, nodo nodo){
        nodo = new nodo(lista, null);
    }
    public void creaRaiz(String dato){
        nodo raiz = new nodo(dato, null);
    }
    public int setDias(int dia) {
        this.dias = dia;
        return dia;
    }
    public int getDia() {
        return dias;
    }

    public void creaEncuesta() {
        System.out.println("Encuesta sobre alimentacion");
        System.out.println("Indique su nombre o el del paciente");
        Scanner sc = new Scanner(System.in);
        String nombre = sc.nextLine();
        System.out.println("Se procede a realizar la encuesta para " + nombre);
        arbol.creaRaiz("Encuesta");
        encuesta.añadirNodo("Encuesta", null);
        System.out.println("Indique que dia va ha añadir (1-5)");
        int dia = sc.nextInt();
        setDias(dia);
        switch (dia) {
            case 1:
                System.out.println("Seleccione ingesta: 1 (Desayuno) / 2 (Media mañana) / 3 (Almuerzo) / 4 (Merienda) / 5 (Cena)/-1 (Menu Anterior)");
                int ingesta = sc.nextInt();
                switch (ingesta) {
                    case 1:
                        desayuno.creaDesayuno();
                        arbol.añaderama(desayuno.getLista(), dia1);
                        break;
                    case 2:
                        desayuno.creamedia();
                        arbol.añaderama(desayuno.getLista(), dia1);
                        break;
                    case 3:
                        desayuno.creaalmu();
                        arbol.añaderama(desayuno.getLista(), dia1);
                        break;
                    case 4:
                        desayuno.creamerienda();
                        arbol.añaderama(desayuno.getLista(), dia1);
                        break;
                    case 5:
                        desayuno.creacena();
                        arbol.añaderama(desayuno.getLista(), dia1);
                        break;
                    case -1:
                        System.out.println("Menu anterior");
                        break;
                    default:
                        System.out.println("Opcion no valida");
                        break;



                }
            case 2:
                System.out.println("Seleccione ingesta: 1 (Desayuno) / 2 (Media mañana) / 3 (Almuerzo) / 4 (Merienda) / 5 (Cena)/-1 (Menu Anterior)");
                int ingesta2 = sc.nextInt();
                switch (ingesta2) {
                    case 1:
                        desayuno.creaDesayuno();
                        arbol.añaderama(desayuno.getLista(), dia2);
                        break;
                    case 2:
                        desayuno.creamedia();
                        arbol.añaderama(desayuno.getLista(), dia2);
                        break;
                    case 3:
                        desayuno.creaalmu();
                        arbol.añaderama(desayuno.getLista(), dia2);
                        break;
                    case 4:
                        desayuno.creamerienda();
                        arbol.añaderama(desayuno.getLista(), dia2);
                        break;
                    case 5:
                        desayuno.creacena();
                        arbol.añaderama(desayuno.getLista(), dia2);
                        break;
                    case -1:
                        System.out.println("Menu anterior");
                        break;
                    default:
                        System.out.println("Opcion no valida");
                        break;



                }
                case 3:
                    System.out.println("Seleccione ingesta: 1 (Desayuno) / 2 (Media mañana) / 3 (Almuerzo) / 4 (Merienda) / 5 (Cena)/-1 (Menu Anterior)");
                    int ingesta3 = sc.nextInt();
                    switch (ingesta3) {
                        case 1:
                            desayuno.creaDesayuno();
                            arbol.añaderama(desayuno.getLista(), dia3);
                            break;
                        case 2:
                            desayuno.creamedia();
                            arbol.añaderama(desayuno.getLista(), dia3);
                            break;
                        case 3:
                            desayuno.creaalmu();
                            arbol.añaderama(desayuno.getLista(), dia3);
                            break;
                        case 4:
                            desayuno.creamerienda();
                            arbol.añaderama(desayuno.getLista(), dia3);
                            break;
                        case 5:
                            desayuno.creacena();
                            arbol.añaderama(desayuno.getLista(), dia3);
                            break;
                        case -1:
                            System.out.println("Menu anterior");
                            break;
                        default:
                            System.out.println("Opcion no valida");
                            break;



                    }
            case 4:
                System.out.println("Seleccione ingesta: 1 (Desayuno) / 2 (Media mañana) / 3 (Almuerzo) / 4 (Merienda) / 5 (Cena)/-1 (Menu Anterior)");
                int ingesta4 = sc.nextInt();
                switch (ingesta4) {
                    case 1:
                        desayuno.creaDesayuno();
                        arbol.añaderama(desayuno.getLista(), dia4);
                        break;
                    case 2:
                        desayuno.creamedia();
                        arbol.añaderama(desayuno.getLista(), dia4);
                        break;
                    case 3:
                        desayuno.creaalmu();
                        arbol.añaderama(desayuno.getLista(), dia4);
                        break;
                    case 4:
                        desayuno.creamerienda();
                        arbol.añaderama(desayuno.getLista(), dia4);
                        break;
                    case 5:
                        desayuno.creacena();
                        arbol.añaderama(desayuno.getLista(), dia4);
                        break;
                    case -1:
                        System.out.println("Menu anterior");
                        break;
                    default:
                        System.out.println("Opcion no valida");
                        break;



                }
            case 5:
                System.out.println("Seleccione ingesta: 1 (Desayuno) / 2 (Media mañana) / 3 (Almuerzo) / 4 (Merienda) / 5 (Cena)/-1 (Menu Anterior)");
                int ingesta5 = sc.nextInt();
                switch (ingesta5) {
                    case 1:
                        desayuno.creaDesayuno();
                        arbol.añaderama(desayuno.getLista(), dia5);
                        break;
                    case 2:
                        desayuno.creamedia();
                        arbol.añaderama(desayuno.getLista(), dia5);
                        break;
                    case 3:
                        desayuno.creaalmu();
                        arbol.añaderama(desayuno.getLista(), dia5);
                        break;
                    case 4:
                        desayuno.creamerienda();
                        arbol.añaderama(desayuno.getLista(), dia5);
                        break;
                    case 5:
                        desayuno.creacena();
                        arbol.añaderama(desayuno.getLista(), dia5);
                        break;
                    case -1:
                        System.out.println("Menu anterior");
                        break;
                    default:
                        System.out.println("Opcion no valida");
                        break;



                }
            default:
                System.out.println("Opcion no valida");
                break;

        }


    }
}
