import java.util.ArrayList;
import java.util.List;

public class Encuesta {

    Arbol arbol = new Arbol("Encuesta");
    nodo nodo = new nodo("Encuesta", null);

    List<nodo> lista = new ArrayList<nodo>();

    public Encuesta() {
        lista.add(nodo);
    }

    public void añadirNodo(String dato, nodo padre){
        nodo hijo = new nodo(dato, padre);
        lista.add(hijo);
    }



}
