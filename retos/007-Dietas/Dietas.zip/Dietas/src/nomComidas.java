public enum nomComidas {
    Desayuno, Mediamañana, Almuerzo, Merienda,Cena;
}
